import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import OpenAI from 'openai';

const app = express();
const port = Number(process.env.PORT || 3000);
// Provider switch: `openai` or `openai-compatible` (for a separately hosted model endpoint).
const provider = (process.env.AI_PROVIDER || 'openai').trim().toLowerCase();
const apiKey = process.env.AI_API_KEY || process.env.OPENAI_API_KEY || '';
const baseURL = (process.env.AI_BASE_URL || '').trim();
const model = process.env.AI_MODEL || process.env.OPENAI_MODEL || (provider === 'openai-compatible' ? 'your-model-name' : 'gpt-6-astra');

app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
// Packaged Android WebViews may send Origin: null. CORS is not authentication.
app.use(cors({ origin: true, methods: ['GET', 'POST', 'OPTIONS'], allowedHeaders: ['Content-Type'] }));
app.use(express.json({ limit: '24kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));

function providerConfigured() {
  if (!apiKey) return false;
  if (provider === 'openai') return true;
  if (provider === 'openai-compatible') return Boolean(baseURL);
  return false;
}

app.get('/health', (_req, res) => res.json({
  ok: true,
  service: 'BAMAX AI backend',
  provider,
  model,
  configured: providerConfigured()
}));

app.post('/api/chat', async (req, res) => {
  if (!['openai', 'openai-compatible'].includes(provider)) {
    return res.status(503).json({ error: 'Unknown AI_PROVIDER. Use openai or openai-compatible.' });
  }
  if (!providerConfigured()) {
    return res.status(503).json({ error: provider === 'openai-compatible'
      ? 'Set AI_API_KEY and AI_BASE_URL on the server.'
      : 'Set OPENAI_API_KEY (or AI_API_KEY) in the server environment.' });
  }
  const messages = req.body?.messages;
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > 12) {
    return res.status(400).json({ error: 'Send between 1 and 12 chat messages.' });
  }
  const clean = [];
  for (const item of messages) {
    if (!item || !['user', 'assistant'].includes(item.role) || typeof item.content !== 'string') {
      return res.status(400).json({ error: 'Each message needs a user/assistant role and text content.' });
    }
    const content = item.content.trim();
    if (!content || content.length > 4000) return res.status(400).json({ error: 'Each message must be 1–4000 characters.' });
    clean.push({ role: item.role, content });
  }
  try {
    const clientOptions = { apiKey };
    if (provider === 'openai-compatible') clientOptions.baseURL = baseURL;
    const client = new OpenAI(clientOptions);
    const instructions = [
      'You are BAMAX, a friendly, thoughtful personal AI assistant designed to help people, communities, animals, and the environment.',
      'Reply in the language the user uses whenever possible, including Sinhala; handle mixed-language messages naturally.',
      'Be compassionate without claiming you can accurately detect a person’s emotions. Treat emotional cues as uncertain and ask gently when needed.',
      'Respect privacy and user choice. Do not claim to control the phone, access the microphone in the background, or operate real-world devices unless an explicitly configured feature does so.',
      'Be clear that you are software, not a physical robot. Keep responses suitable for a teen user.'
    ].join(' ');
    let reply = '';
    if (provider === 'openai') {
      const response = await client.responses.create({
        model,
        instructions,
        input: clean.map(m => ({ role: m.role, content: m.content }))
      });
      reply = response.output_text?.trim() || '';
    } else {
      // Chat Completions is supported by more OpenAI-compatible local/open models.
      const response = await client.chat.completions.create({
        model,
        messages: [{ role: 'system', content: instructions }, ...clean],
        max_tokens: 1200
      });
      reply = response.choices?.[0]?.message?.content?.trim() || '';
    }
    if (!reply) return res.status(502).json({ error: 'The AI returned no text. Please try again.' });
    res.json({ reply, provider, model });
  } catch (err) {
    console.error('AI request failed:', err?.status || '', err?.message || 'unknown error');
    if (err?.status === 401) return res.status(502).json({ error: 'The server AI key was rejected. Check the server secret.' });
    if (err?.status === 429) return res.status(429).json({ error: 'AI usage limit reached. Check the provider usage limits and try later.' });
    res.status(502).json({ error: 'The AI provider request failed. Check the provider endpoint, model name, and server logs.' });
  }
});

app.listen(port, '0.0.0.0', () => console.log(`BAMAX backend listening on port ${port}; provider=${provider}; model=${model}`));
