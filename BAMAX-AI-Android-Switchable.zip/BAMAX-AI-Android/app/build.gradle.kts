plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bamax.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.bamax.ai"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.2.0"
    }
}
