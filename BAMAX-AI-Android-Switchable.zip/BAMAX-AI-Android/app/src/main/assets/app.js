(() => {
  'use strict';
  const $ = (selector) => document.querySelector(selector);
  const messages = $('#messages');
  const form = $('#chatForm');
  const input = $('#messageInput');
  const status = $('#systemStatus');
  const subtitle = $('#heroSubtitle');
  const voiceSelect = $('#voiceSelect');
  const rateRange = $('#rateRange');
  const pitchRange = $('#pitchRange');
  const sendButton = $('.send-button');
  const backendInput = $('#backendUrl');
  const connectionPill = $('#connectionPill');
  let voices = [];
  let recognition = null;
  let chatHistory = [];
  let busy = false;

  function updateClock() {
    const now = new Date();
    $('#clock').textContent = now.toLocaleTimeString([], { hour12: false });
    $('#dateLabel').textContent = now.toLocaleDateString([], { day: '2-digit', month: 'short', year: 'numeric' }).toUpperCase();
  }
  updateClock();
  setInterval(updateClock, 1000);

  const savedBackend = localStorage.getItem('bamaxBackendUrl') || '';
  backendInput.value = savedBackend;
  function normalizedBackend() { return backendInput.value.trim().replace(/\/+$/, ''); }
  function updateConnectionUi(connected, label) {
    status.textContent = connected ? 'AI BACKEND READY' : 'SYSTEM ONLINE';
    connectionPill.innerHTML = '<i></i> ' + (label || (connected ? 'AI CONNECTED' : 'AI NOT CONNECTED'));
    $('#inputHint').textContent = connected ? 'AI backend configured · Usage may incur API charges.' : 'Demo mode · Connect a secure backend in Settings to enable real AI replies.';
  }
  updateConnectionUi(Boolean(savedBackend));

  function loadVoices() {
    if (!('speechSynthesis' in window)) return;
    voices = window.speechSynthesis.getVoices();
    const previous = voiceSelect.value;
    voiceSelect.replaceChildren(new Option('Default device voice', ''));
    voices.forEach((voice, index) => voiceSelect.add(new Option(`${voice.name} (${voice.lang})`, String(index))));
    if (previous && [...voiceSelect.options].some(o => o.value === previous)) voiceSelect.value = previous;
  }
  if ('speechSynthesis' in window) {
    loadVoices();
    window.speechSynthesis.addEventListener?.('voiceschanged', loadVoices);
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }

  function speak(text) {
    if (!('speechSynthesis' in window)) { setStatus('VOICE NOT SUPPORTED'); return; }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const voiceIndex = voiceSelect.value;
    if (voiceIndex !== '' && voices[Number(voiceIndex)]) utterance.voice = voices[Number(voiceIndex)];
    utterance.rate = Number(rateRange.value);
    utterance.pitch = Number(pitchRange.value);
    utterance.onstart = () => { subtitle.textContent = 'BAMAX is speaking.'; setStatus('VOICE ACTIVE'); };
    utterance.onend = () => { subtitle.textContent = 'Ready when you are.'; setStatus(normalizedBackend() ? 'AI BACKEND READY' : 'SYSTEM ONLINE'); };
    utterance.onerror = () => { subtitle.textContent = 'Ready when you are.'; setStatus('SYSTEM ONLINE'); };
    window.speechSynthesis.speak(utterance);
  }
  function setStatus(text) { status.textContent = text; }

  function addMessage(text, who, shouldSpeak = false, options = {}) {
    const row = document.createElement('div');
    row.className = `message ${who === 'user' ? 'user-message' : 'assistant-message'}`;
    if (options.loading) row.classList.add('loading-message');
    const avatar = document.createElement('span'); avatar.className = 'message-avatar'; avatar.textContent = who === 'user' ? 'YOU' : 'B';
    const body = document.createElement('div');
    const label = document.createElement('span'); label.className = 'message-label'; label.textContent = who === 'user' ? 'YOU' : 'BAMAX';
    const paragraph = document.createElement('p'); paragraph.textContent = text;
    body.append(label, paragraph);
    if (who !== 'user' && !options.loading) {
      const play = document.createElement('button'); play.className = 'speak-button'; play.type = 'button'; play.textContent = '▶ Play voice';
      play.addEventListener('click', () => speak(text)); body.append(play);
    }
    row.append(avatar, body); messages.append(row); messages.scrollTop = messages.scrollHeight;
    if (shouldSpeak) speak(text);
    return row;
  }

  function demoReply(raw) {
    const text = raw.toLowerCase().trim();
    if (/^(hi|hello|hey|හායි|හෙලෝ|ආයුබෝවන්)\b/.test(text)) return 'Hello! I’m BAMAX, your personal assistant prototype. Connect my secure AI backend in Settings to unlock real AI conversations.';
    if (text.includes('who are you') || text.includes('ඔයා කවුද') || text.includes('ඔයාගේ නම')) return 'මම BAMAX — ඔයාගේ personal AI assistant project එක. සැබෑ AI පිළිතුරු සඳහා Settings වලින් secure backend එකක් සම්බන්ධ කරන්න.';
    if (text.includes('what can you do') || text.includes('capabilities') || text.includes('මොනවද කරන්න')) return 'මට voice output, supported browsers වල voice input, සහ chat interface එක තියෙනවා. Secure backend එක සම්බන්ධ කළාම සැබෑ AI පිළිතුරු ලබාගන්න පුළුවන්.';
    if (text.includes('status') || text.includes('system')) return 'Interface status: online. AI backend: ' + (normalizedBackend() ? 'configured; connection will be tested when you send a message.' : 'not configured yet.') + ' Device voice: ' + ('speechSynthesis' in window ? 'available' : 'not supported') + '.';
    if (text.includes('baymax') || text.includes('robot')) return 'අපි BAMAX එක පියවරෙන් පියවර දියුණු කරමු: secure AI, voice interaction, සහ පසුව ආරක්ෂිතව පරීක්ෂා කරන robot hardware integration.';
    if (/[\u0D80-\u0DFF]/.test(raw)) return 'මේක තවම demo mode එකේ. සැබෑ Sinhala/English AI පිළිතුරු ලබාගන්න Settings වෙත ගොස් secure backend URL එක සම්බන්ධ කරන්න.';
    return 'BAMAX is currently in demo mode. Open Settings and add your deployed HTTPS AI backend URL to enable real AI replies.';
  }

  async function getAiReply() {
    const base = normalizedBackend();
    if (!base) return demoReply(chatHistory[chatHistory.length - 1].content);
    const response = await fetch(base + '/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: chatHistory.slice(-12) })
    });
    let data = {};
    try { data = await response.json(); } catch (_) {}
    if (!response.ok) throw new Error(data.error || `Backend request failed (${response.status})`);
    if (!data.reply || typeof data.reply !== 'string') throw new Error('The backend returned an empty reply.');
    return data.reply;
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const text = input.value.trim();
    if (!text || busy) return;
    addMessage(text, 'user'); input.value = '';
    chatHistory.push({ role: 'user', content: text });
    busy = true; sendButton.disabled = true; input.disabled = true; setStatus(normalizedBackend() ? 'CONTACTING AI' : 'DEMO MODE');
    subtitle.textContent = normalizedBackend() ? 'Connecting to BAMAX AI brain…' : 'Running local demo mode.';
    const loading = addMessage('Thinking…', 'assistant', false, { loading: true });
    try {
      const reply = await getAiReply();
      loading.remove(); addMessage(reply, 'assistant');
      chatHistory.push({ role: 'assistant', content: reply });
      updateConnectionUi(Boolean(normalizedBackend()), normalizedBackend() ? 'AI CONNECTED' : 'LOCAL DEMO');
    } catch (error) {
      loading.remove();
      addMessage('I couldn’t reach the AI backend. Check the HTTPS URL, deployment status, and server logs. Details: ' + error.message, 'assistant');
      updateConnectionUi(false, 'CONNECTION ERROR');
    } finally {
      busy = false; sendButton.disabled = false; input.disabled = false; input.focus();
      subtitle.textContent = 'Ready when you are.';
    }
  });

  document.querySelectorAll('.action-card').forEach(button => button.addEventListener('click', () => { input.value = button.dataset.prompt || ''; form.requestSubmit(); }));
  document.querySelectorAll('[data-speak]').forEach(button => button.addEventListener('click', () => speak(button.dataset.speak)));
  $('#settingsBtn').addEventListener('click', () => { $('#settingsPanel').hidden = !$('#settingsPanel').hidden; if (!$('#settingsPanel').hidden) $('#settingsPanel').scrollIntoView({ behavior: 'smooth', block: 'nearest' }); });
  $('#closeSettings').addEventListener('click', () => { $('#settingsPanel').hidden = true; });
  $('#saveBackend').addEventListener('click', async () => {
    const url = normalizedBackend();
    if (url && !/^https:\/\//i.test(url)) { subtitle.textContent = 'Use an HTTPS backend URL for security.'; return; }
    localStorage.setItem('bamaxBackendUrl', url); updateConnectionUi(Boolean(url), url ? 'BACKEND SAVED' : 'LOCAL DEMO');
    subtitle.textContent = url ? 'Backend URL saved. Send a message to test the connection.' : 'Backend removed. Running local demo mode.';
    if (url) {
      try { const r = await fetch(url + '/health'); if (!r.ok) throw new Error(); subtitle.textContent = 'Backend is reachable. Send a message to test AI replies.'; }
      catch (_) { subtitle.textContent = 'URL saved, but the backend health check failed. Verify the deployed URL.'; }
    }
  });
  rateRange.addEventListener('input', () => { $('#rateValue').value = `${Number(rateRange.value).toFixed(2).replace(/0$/, '')}×`; });
  pitchRange.addEventListener('input', () => { $('#pitchValue').value = Number(pitchRange.value).toFixed(2).replace(/0$/, ''); });
  $('#testVoice').addEventListener('click', () => speak('Hello. I am BAMAX. Your personal assistant is ready. Let us build something amazing.'));

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const micBtn = $('#micBtn');
  if (SpeechRecognition) {
    recognition = new SpeechRecognition(); recognition.lang = 'en-US'; recognition.interimResults = false; recognition.maxAlternatives = 1;
    recognition.onstart = () => { micBtn.classList.add('listening'); micBtn.textContent = '⏺'; setStatus('LISTENING'); subtitle.textContent = 'I’m listening...'; };
    recognition.onresult = event => { input.value = event.results[0][0].transcript; form.requestSubmit(); };
    recognition.onerror = () => { setStatus('SYSTEM ONLINE'); subtitle.textContent = 'Voice input unavailable. You can type instead.'; };
    recognition.onend = () => { micBtn.classList.remove('listening'); micBtn.textContent = '🎙'; if (status.textContent === 'LISTENING') setStatus('SYSTEM ONLINE'); if (!('speechSynthesis' in window && window.speechSynthesis.speaking)) subtitle.textContent = 'Ready when you are.'; };
    micBtn.addEventListener('click', () => { try { recognition.start(); } catch (_) { recognition.stop(); } });
  } else { micBtn.addEventListener('click', () => { subtitle.textContent = 'Voice input is not supported here. You can type your message.'; }); micBtn.title = 'Voice input not supported by this browser'; }
})();
