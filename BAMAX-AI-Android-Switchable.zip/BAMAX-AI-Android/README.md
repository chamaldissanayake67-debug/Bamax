# BAMAX AI Android + Switchable AI Backend (Version 1.2)

BAMAX AI is a mobile-first assistant prototype with a JARVIS-inspired interface, device text-to-speech, optional browser speech input, and an Android WebView shell. Its server-side AI provider is configurable so you can start with OpenAI and later switch to a separately hosted OpenAI-compatible model without rebuilding the Android interface.

## Build a test APK on GitHub
1. Upload the contents of this folder to the root of a GitHub repository.
2. Open **Actions** → **Build BAMAX AI APK** → **Run workflow** (or push to `main`).
3. Download the `BAMAX-AI-debug-APK` artifact from the completed workflow and extract `app-debug.apk`.
4. Install it on your Android phone. This is a debug/testing APK, not a Play Store release.

## Option A — Start with OpenAI
1. Deploy the `backend` folder as a Node.js web service on a trusted hosting provider.
2. Set the service root to `backend` if your host requires it; start command: `npm start`.
3. In the hosting dashboard's secret/environment settings, set `AI_PROVIDER=openai` and `OPENAI_API_KEY` to your private API key. Set `OPENAI_MODEL` to a model enabled for your API account.
4. Open `https://YOUR-SERVICE/health`. The JSON should show `ok: true` and `configured: true`.
5. In BAMAX AI → Settings, enter the service's HTTPS base URL (without `/api/chat`) and save. Send a message to test it.

## Option B — Switch later to another model
Use this when you have a model hosted behind an **OpenAI-compatible API endpoint**. The alternate provider uses the widely supported Chat Completions endpoint. The server must expose an OpenAI-compatible `/chat/completions` endpoint; check the provider documentation for the exact base URL and model name.

Set these environment variables on the server:
- `AI_PROVIDER=openai-compatible`
- `AI_API_KEY=...` (if the provider requires a key; if it does not, use a non-empty private server-side token and configure the provider accordingly)
- `AI_BASE_URL=https://your-provider.example/v1`
- `AI_MODEL=the-exact-model-name`

Restart/redeploy the backend. The Android app's backend URL stays the same. To switch back, set `AI_PROVIDER=openai`, configure `OPENAI_API_KEY` and `OPENAI_MODEL`, then redeploy.

## Security and cost
- **Never put an API key in the Android app, HTML/JavaScript, screenshots, or a public GitHub repository.** Keep keys in server-side environment secrets. See the [official OpenAI API key safety guidance](https://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety).
- API usage may cost money and requires an API account with access and billing/limits configured. ChatGPT subscription access and API billing are separate.
- This prototype has basic rate limiting, but CORS is not authentication. Before sharing it publicly, add user authentication, per-user quotas, abuse protection, and privacy controls.
- Do not commit `.env` files. `.env.example` contains placeholders only.

## Current limitations
- This build does not yet implement a reliable always-on “Hey BAMAX” wake word, continuous background listening, emotion recognition, broad Android phone control, or physical robot control. Android background microphone restrictions and permissions must be handled explicitly; voice cues cannot reliably determine a person's feelings by themselves.
- Voice input/output depends on the phone, browser/WebView, installed speech services, and supported languages. The assistant prompt asks the AI to reply in the user's language, but voice recognition is currently browser/device-dependent.
- The real robot phase needs separate hardware, sensor, movement, emergency-stop, and safety engineering.

## Local backend test
Requires Node.js 20+. In `backend`: run `npm install`, set provider environment variables, then run `npm start`.
